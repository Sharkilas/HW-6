import express, {Response, Request, Router} from 'express';
import { emailValidation, loginValidation, passwordValidation } from '../Validation/userValidation';
import { httpStatusCodes } from '../http-status-codes/http-status-codes';
import { errorValidationMiddleware } from '../Validation/postValidation';
import { userService } from '../domain/userService';

export const userAuthRouter = Router ({})  

userAuthRouter.post('/login', 
loginValidation,
emailValidation,
passwordValidation,
errorValidationMiddleware,
async (req: Request, res: Response) => {
  const newUser =  await userService.createUser(req.body.login, req.body.email, req.body.password)
    res.status(httpStatusCodes.CREATED_201).send(newUser)
})