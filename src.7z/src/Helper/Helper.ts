export function getRandomId(): string {
    return (+new Date()).toString();
}
export const currentDate = new Date();